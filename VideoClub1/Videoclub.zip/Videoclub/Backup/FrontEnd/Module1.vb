﻿Imports NEGOCIO
Module Module1

    Sub Main()
        Dim comando As New Operaciones()

        comando.MenuPrincipal()
    End Sub

End Module
